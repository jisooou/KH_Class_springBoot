package com.kh.app04;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App04ApplicationTests {

	@Test
	void contextLoads() {
	}

}
